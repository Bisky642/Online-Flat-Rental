
package com.cg.ofr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.ofr.entities.Flat;
import com.cg.ofr.entities.FlatAddress;
import com.cg.ofr.entities.FlatBooking;
import com.cg.ofr.entities.Payment;
import com.cg.ofr.entities.Tenant;

import com.cg.ofr.exception.PaymentNotFoundException;

import com.cg.ofr.service.IPaymentService;

@SpringBootTest
public class PaymentTests extends OnlineFlatRentalApplicationTests {

	@Autowired
	private IPaymentService paymentService;

	@Test
	public void addPaymentTest1() {

		FlatAddress flatAddress = new FlatAddress(100, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(1001, 100000, flatAddress, "yes");
		Tenant tenant = new Tenant(21, 20, null);
		FlatBooking flatBooking = new FlatBooking(151, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(121, flatBooking, "not paid");
		assertNotNull(payment.getStatus());

	}

	@Test
	public void addPaymentTest2() {

		FlatAddress flatAddress = new FlatAddress(121, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(1021, 100000, flatAddress, "yes");
		Tenant tenant = new Tenant(61, 20, null);
		FlatBooking flatBooking = new FlatBooking(191, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(131, flatBooking, "not paid");
		assertNotNull(payment.getStatus());

	}

	@Test
	public void getPaymentTest1() throws PaymentNotFoundException {
		FlatAddress flatAddress = new FlatAddress(101, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(1002, 100000, flatAddress, "no");
		Tenant tenant = new Tenant(22, 20, null);
		FlatBooking flatBooking = new FlatBooking(152, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(122, flatBooking, "not paid");
		paymentService.addPayment(payment);
		Payment paymentTest = paymentService.getPaymentDetails(payment.getPaymentId());
		assertEquals(payment.getPaymentId(), paymentTest.getPaymentId());

	}

	@Test
	public void getPaymentTest2() throws PaymentNotFoundException {
		FlatAddress flatAddress = new FlatAddress(122, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(1032, 100000, flatAddress, "no");
		Tenant tenant = new Tenant(63, 20, null);
		FlatBooking flatBooking = new FlatBooking(192, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(132, flatBooking, "not paid");
		paymentService.addPayment(payment);
		Payment paymentTest = paymentService.getPaymentDetails(payment.getPaymentId());
		assertEquals(payment.getPaymentId(), paymentTest.getPaymentId());

	}

	@Test
	public void updatePaymentTest1() {
		FlatAddress flatAddress = new FlatAddress(102, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(1003, 100000, flatAddress, "yes");
		Tenant tenant = new Tenant(23, 20, null);
		FlatBooking flatBooking = new FlatBooking(153, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(123, flatBooking, "not paid");
		paymentService.addPayment(payment);
		Payment paymentNew = new Payment(123, flatBooking, "paid");
		Payment testPayment = paymentService.updatePayment(paymentNew);
		assertEquals(paymentNew.getStatus(), testPayment.getStatus());
	}

	@Test
	public void updatePaymentTest2() {
		FlatAddress flatAddress = new FlatAddress(152, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(1343, 100000, flatAddress, "yes");
		Tenant tenant = new Tenant(63, 20, null);
		FlatBooking flatBooking = new FlatBooking(183, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(133, flatBooking, "not paid");
		paymentService.addPayment(payment);
		Payment paymentNew = new Payment(133, flatBooking, "paid");
		Payment testPayment = paymentService.updatePayment(paymentNew);
		assertEquals(paymentNew.getStatus(), testPayment.getStatus());

	}

	@Test
	public void deletePaymentTest1() {
		FlatAddress flatAddress = new FlatAddress(199, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(199, 100000, flatAddress, "yes");
		Tenant tenant = new Tenant(199, 20, null);
		FlatBooking flatBooking = new FlatBooking(199, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(199, flatBooking, "paid");
		paymentService.addPayment(payment);
		Payment paymentTest = paymentService.deletePayment(payment);
		assertNotNull(paymentTest);

	}

	@Test
	public void deletePaymentTest2() {
		FlatAddress flatAddress = new FlatAddress(161, "9", "hyderabad", "telangana", 500092, "India");
		Flat flat = new Flat(111, 100000, flatAddress, "yes");
		Tenant tenant = new Tenant(101, 20, null);
		FlatBooking flatBooking = new FlatBooking(1231, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 11, 21), flat,
				tenant);
		tenant.setFlatbooking(flatBooking);
		Payment payment = new Payment(136, flatBooking, "paid");
		paymentService.addPayment(payment);
		Payment paymentTest = paymentService.deletePayment(payment);
		assertNotNull(paymentTest);

	}

	@Test
	public void getAllPaymentTest1() {
		assertNotNull(paymentService.getAllPaymentDetails());

	}

	@Test
	public void getAllPaymentTest2() {
		assertNotNull(paymentService.getAllPaymentDetails());

	}

}
