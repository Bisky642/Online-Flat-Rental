package com.cg.ofr.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cg.ofr.exception.EmptyEntityListException;
import com.cg.ofr.exception.EntityCreationException;
import com.cg.ofr.exception.EntityDeletionException;
import com.cg.ofr.exception.EntityUpdationException;
import com.cg.ofr.exception.FlatBookingNotFoundException;
import com.cg.ofr.exception.FlatNotFoundException;
import com.cg.ofr.exception.LandlordNotFoundException;
import com.cg.ofr.exception.PaymentNotFoundException;
import com.cg.ofr.exception.TenantNotFoundException;
import com.cg.ofr.exception.UserNotFoundException;

/************************************************************************************
 *          @author          B.Sai Kiran
 *          Description      It is a controller advice class that handles the exceptions
  *         Version             1.0
  *         Created Date    25-MARCH-2021
 ************************************************************************************/
@RestControllerAdvice
public class ControllerAdvice {

	/************************************************************************************
	 * Method:                          entityCreation
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(EntityCreationException.class)
	public ResponseEntity<String> entityCreation(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

	/************************************************************************************
	 * Method:                          entityDeletion
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(EntityDeletionException.class)
	public ResponseEntity<String> entityDeletion(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}


	/************************************************************************************
	 * Method:                          flatBookingNotFound
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(FlatBookingNotFoundException.class)
	public ResponseEntity<String> flatBookingNotFound(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

	/************************************************************************************
	 * Method:                          flatNotFound
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(FlatNotFoundException.class)
	public ResponseEntity<String> flatNotFound(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

	/************************************************************************************
	 * Method:                          tenantNotFound
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(TenantNotFoundException.class)
	public ResponseEntity<String> tenantNotFound(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}


	/************************************************************************************
	 * Method:                          landlordrNotFound
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(LandlordNotFoundException.class)
	public ResponseEntity<String> landlordNotFound(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}


	/************************************************************************************
	 * Method:                          entityNotFound
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(PaymentNotFoundException.class)
	public ResponseEntity<String> entityNotFound(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

	/************************************************************************************
	 * Method:                          userNotFound
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<String> userNotFound(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}


	/************************************************************************************
	 * Method:                          emptyEntityList
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(EmptyEntityListException.class)
	public ResponseEntity<String> emptyEntityList(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

	/************************************************************************************
	 * Method:                          entityUpdation
     *Description:                      It is used to return the exception message and its HTTP status
	 * @returns Response entity         It returns the exception message and its HTTP status.
	 * @param exception                 It is parent class of exception
                *Created By                                - B.Sai Kiran
                *Created Date                            - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@ExceptionHandler(EntityUpdationException.class)
	public ResponseEntity<String> entityUpdation(Exception e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}
}