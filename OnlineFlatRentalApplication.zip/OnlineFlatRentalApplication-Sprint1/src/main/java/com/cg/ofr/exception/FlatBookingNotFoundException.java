package com.cg.ofr.exception;

public class FlatBookingNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public FlatBookingNotFoundException(String message) {
		super(message);

	}

}
